//
//  Computer Use Acceptance Fixture (Windows, WinForms)
//  A small native visual target range for screenshot-only computer-use agents.
//  No network, no file access except the optional coordinator-owned evidence file.
//
//  Usage: acceptance-fixture.exe [--seed N] [--evidence-file PATH]
//                                [--suite legacy|baseline|punctuation|emoji|known-input|multiclick|drag|scroll|pointer|keyboard|focus]
//                                [--self-test | --export-cases PATH | --export-platform-cases PATH | --export-focus-cases PATH]
//  Windows builds include NativeText*.cs by default: known-09 uses an explicit
//  native expected policy; --export-native-text-policy PATH exports it separately.
//  The historical canonical case catalog and --export-cases remain unchanged.
//  Omitting --suite keeps the historical legacy single-sample behavior; legacy
//  results must never be merged with layered-suite results.
//  --self-test / --export-cases are console modes: no window is created; the
//  exit code is authoritative (stdout only appears when redirected, e.g. ssh).
//

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace AcceptanceFixture
{
    // MARK: - Deterministic RNG (SplitMix64)

    sealed class SplitMix64
    {
        private ulong _state;
        public SplitMix64(ulong seed) { _state = seed; }
        public ulong Next()
        {
            unchecked
            {
                _state += 0x9E3779B97F4A7C15UL;
                ulong z = _state;
                z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
                z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
                return z ^ (z >> 31);
            }
        }
        public int Below(int n) { return (int)(Next() % (ulong)n); }
        public void Shuffle<T>(T[] arr)
        {
            for (int i = arr.Length - 1; i > 0; i--)
            {
                int j = Below(i + 1);
                T tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
            }
        }
    }

    // MARK: - Evidence logger (coordinator-only JSONL oracle)

    sealed class EvidenceLogger
    {
        private readonly string _path;
        private readonly string _runID=Guid.NewGuid().ToString(), _sessionID=Guid.NewGuid().ToString();
        private EvidenceLogger(string path) { _path = path; }

        public static EvidenceLogger Create(string path)
        {
            if (string.IsNullOrEmpty(path)) return null;
            if (!File.Exists(path)) File.WriteAllText(path, "");
            return new EvidenceLogger(path);
        }

        private static string Escape(string s)
        {
            var sb = new StringBuilder(s.Length + 8);
            foreach (char c in s)
            {
                if (c == '"') sb.Append("\\\"");
                else if (c == '\\') sb.Append("\\\\");
                else if (c < 0x20) sb.Append("\\u" + ((int)c).ToString("x4"));
                else sb.Append(c);
            }
            return sb.ToString();
        }

        private static string Pair(string k, object v)
        {
            if (v is bool) return "\"" + k + "\":" + (((bool)v) ? "true" : "false");
            if (v is int || v is long || v is ulong || v is uint || v is double || v is float)
                return "\"" + k + "\":" + Convert.ToString(v, CultureInfo.InvariantCulture);
            return "\"" + k + "\":\"" + Escape(Convert.ToString(v)) + "\"";
        }

        public void Log(string type, params object[] kvPairs)
        {
            var sb = new StringBuilder();
            sb.Append("{\"type\":\"").Append(Escape(type))
              .Append("\",\"ts\":\"").Append(DateTime.UtcNow.ToString("o")).Append("\"");
            sb.Append(',').Append(Pair("run_id", _runID)).Append(',').Append(Pair("session_id", _sessionID));
            for (int i = 0; i + 1 < kvPairs.Length; i += 2)
                sb.Append(',').Append(Pair(Convert.ToString(kvPairs[i]), kvPairs[i + 1]));
            sb.Append('}');
            File.AppendAllText(_path, sb.ToString() + "\r\n", Encoding.UTF8);
        }
    }

    // MARK: - Trial model

    enum ShapeKind { Circle, Square, Triangle, Diamond }

    sealed class Item
    {
        public ShapeKind Kind;
        public Color Color;
        public string ColorName;
        public bool IsTarget;
    }

    static class Palette
    {
        public static readonly Color Green = Color.FromArgb(0, 184, 31);
        public static readonly Color Red = Color.FromArgb(220, 41, 41);
        public static readonly Color Blue = Color.FromArgb(31, 89, 220);
        public static readonly Color Yellow = Color.FromArgb(242, 199, 13);
    }

    // MARK: - Shapes canvas

    sealed class ShapesPanel : Panel
    {
        public Item[] Items = new Item[0];
        public event Action<int> SlotClicked;

        public ShapesPanel() { DoubleBuffered = true; BackColor = Color.White; }

        private Rectangle RectForSlot(int slot)
        {
            const int size = 110;
            int cx = Width * (2 * slot + 1) / 8;
            return new Rectangle(cx - size / 2, Height / 2 - size / 2, size, size);
        }

        private static GraphicsPath PathFor(ShapeKind kind, Rectangle r)
        {
            var p = new GraphicsPath();
            switch (kind)
            {
                case ShapeKind.Circle: p.AddEllipse(r); break;
                case ShapeKind.Square: p.AddRectangle(r); break;
                case ShapeKind.Triangle:
                    p.AddPolygon(new Point[]
                    {
                        new Point(r.X + r.Width / 2, r.Top),
                        new Point(r.Right, r.Bottom),
                        new Point(r.Left, r.Bottom)
                    });
                    break;
                case ShapeKind.Diamond:
                    p.AddPolygon(new Point[]
                    {
                        new Point(r.X + r.Width / 2, r.Top),
                        new Point(r.Right, r.Y + r.Height / 2),
                        new Point(r.X + r.Width / 2, r.Bottom),
                        new Point(r.Left, r.Y + r.Height / 2)
                    });
                    break;
            }
            return p;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            for (int slot = 0; slot < Items.Length; slot++)
            {
                Rectangle r = RectForSlot(slot);
                r.Inflate(-4, -4);
                using (var path = PathFor(Items[slot].Kind, r))
                using (var brush = new SolidBrush(Items[slot].Color))
                using (var pen = new Pen(Color.Black, 3f))
                { e.Graphics.FillPath(brush, path); e.Graphics.DrawPath(pen, path); }
            }
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            for (int slot = 0; slot < Items.Length; slot++)
            {
                if (RectForSlot(slot).Contains(e.Location))
                {
                    var handler = SlotClicked;
                    if (handler != null) handler(slot);
                    return;
                }
            }
        }
    }

    // MARK: - Main form

    sealed class MainForm : Form
    {
        private const string NonceChars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        private const string WindowTitle = "Computer Use Acceptance";

        private readonly SplitMix64 _rng;
        private readonly ulong _seedUsed;
        private readonly EvidenceLogger _logger;
        private readonly SuiteKind _suite;
        private readonly FixtureCase[] _suiteCases;

        private readonly Label _trialLabel;
        private readonly Label _nonceLabel;
        private readonly Label _statusLabel;
        private readonly Label _resultLabel;
        private readonly Label _sampleLabel;
        private readonly TextBox _textBox;
        private readonly ShapesPanel _shapes;

        private int _trialIndex;          // 1-based; in suite mode == case index
        private FixtureCase _currentCase;
        private int _nativeTextCheckIndex;
        private bool _suiteFinished;
        private Item[] _items = new Item[0];
        private int _targetSlot;
        private string _nonce = "";

        public MainForm(SuiteKind suite, string evidencePath, ulong? seed)
        {
            _seedUsed = seed ?? (ulong)DateTime.UtcNow.Ticks;
            _rng = new SplitMix64(_seedUsed);
            _logger = EvidenceLogger.Create(evidencePath);
            _suite = suite;
            _suiteCases = CaseCatalog.CasesFor(suite);

            // --- form ---
            Text = WindowTitle;
            Text += " — Windows native text policy v1";
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            ClientSize = new Size(884, 712); // ~900x750 incl. borders; fits a 1080 screen
            BackColor = Color.White;

            // --- controls ---
            _trialLabel = new Label
            {
                Bounds = new Rectangle(20, 8, 500, 28),
                Font = new Font(FontFamily.GenericSansSerif, 16f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };
            _nonceLabel = new Label
            {
                Bounds = new Rectangle(20, 42, 844, 46),
                Font = new Font("Consolas", 24f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter
            };
            var instr = new Label
            {
                Bounds = new Rectangle(20, 92, 844, 24),
                Font = new Font(FontFamily.GenericSansSerif, 13f),
                TextAlign = ContentAlignment.MiddleCenter,
                Text = "TARGET: the only GREEN CIRCLE — click it"
            };
            _statusLabel = new Label
            {
                Bounds = new Rectangle(20, 120, 844, 42),
                Font = new Font(FontFamily.GenericSansSerif, 22f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.White
            };
            _shapes = new ShapesPanel { Bounds = new Rectangle(20, 168, 844, 196) };
            _shapes.SlotClicked += ShapeClicked;
            // Large wrapping sample; emoji suite uses Segoe UI Emoji at a bigger
            // size to avoid ugly fallback (monochrome rendering is possible and
            // must be reported honestly — see README).
            _sampleLabel = new Label
            {
                Bounds = new Rectangle(20, 370, 844, 142),
                Font = suite == SuiteKind.Emoji
                    ? new Font("Segoe UI Emoji", 32f)
                    : new Font(FontFamily.GenericSansSerif, 24f),
                TextAlign = ContentAlignment.TopLeft
            };
            _textBox = new TextBox
            {
                Bounds = new Rectangle(20, 518, 844, 120),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                // The agent must reproduce the payload byte-for-byte: Tab must
                // insert a tab (not move focus) and Enter a newline. Comparison
                // stays strict UTF-16 — actual text is logged as-is, never
                // normalized.
                AcceptsTab = true,
                AcceptsReturn = true,
                Font = new Font(FontFamily.GenericSansSerif, 13f)
            };
            _resultLabel = new Label
            {
                Bounds = new Rectangle(20, 646, 330, 38),
                Font = new Font(FontFamily.GenericSansSerif, 11f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };
            var checkBtn = new Button { Bounds = new Rectangle(360, 644, 160, 42), Text = "Check text" };
            var nextBtn = new Button { Bounds = new Rectangle(540, 644, 160, 42), Text = "Next trial" };
            var closeBtn = new Button { Bounds = new Rectangle(720, 644, 160, 42), Text = "Cancel / Close" };
            foreach (var b in new[] { checkBtn, nextBtn, closeBtn })
                b.Font = new Font(FontFamily.GenericSansSerif, 11f, FontStyle.Bold);
            checkBtn.Click += (s, e) => CheckText();
            nextBtn.Click += (s, e) => NextTrial();
            closeBtn.Click += (s, e) => Close();

            Controls.AddRange(new Control[]
            {
                _trialLabel, _nonceLabel, instr, _statusLabel, _shapes, _sampleLabel, _textBox,
                _resultLabel, checkBtn, nextBtn, closeBtn
            });

            if (_logger != null)
                _logger.Log("session", "seed", _seedUsed.ToString(), "platform", "windows",
                            "suite", SuiteNames.Name(_suite)
                            , "native_text_policy_version", NativeTextPolicy.Version,
                            "native_control", NativeTextPolicy.Control
                            );
        }

        // MARK: Trial logic

        private string MakeNonce()
        {
            var sb = new StringBuilder(6);
            for (int i = 0; i < 6; i++) sb.Append(NonceChars[_rng.Below(NonceChars.Length)]);
            return sb.ToString();
        }

        private void DrawShapes()
        {
            var items = new Item[4];
            items[0] = new Item { Kind = ShapeKind.Circle, Color = Palette.Green, ColorName = "green", IsTarget = true };
            var shapes = new[] { ShapeKind.Square, ShapeKind.Triangle, ShapeKind.Diamond };
            _rng.Shuffle(shapes);
            var colors = new[]
            {
                Tuple.Create(Palette.Red, "red"),
                Tuple.Create(Palette.Blue, "blue"),
                Tuple.Create(Palette.Yellow, "yellow")
            };
            _rng.Shuffle(colors);
            for (int i = 0; i < 3; i++)
                items[i + 1] = new Item { Kind = shapes[i], Color = colors[i].Item1, ColorName = colors[i].Item2, IsTarget = false };
            _rng.Shuffle(items);
            _items = items;
            _targetSlot = Array.FindIndex(items, it => it.IsTarget);
            _shapes.Items = _items;
            _shapes.Invalidate();
        }

        public void StartTrial()
        {
            if (_suite != SuiteKind.Legacy && _suiteFinished)
            {
                // Next beyond the last case: no new case; keep SUITE COMPLETE shown.
                return;
            }
            _trialIndex++;
            _nativeTextCheckIndex = 0;
            _nonce = MakeNonce();
            DrawShapes();

            if (_suite == SuiteKind.Legacy)
            {
                _currentCase = _suiteCases[0];
                _trialLabel.Text = "Trial " + _trialIndex;
            }
            else
            {
                _currentCase = _suiteCases[_trialIndex - 1];
                _trialLabel.Text = "Trial " + _trialIndex + "/" + _suiteCases.Length
                    + " — suite: " + SuiteNames.Name(_suite);
            }

            _nonceLabel.Text = "NONCE: " + _nonce;
            _statusLabel.Text = "";
            _statusLabel.ForeColor = Color.Black;
            _statusLabel.BackColor = Color.White;
            _resultLabel.Text = "";
            _sampleLabel.Text = _currentCase != null ? "Type exactly:  " + _currentCase.Payload : "";
            _textBox.Text = "";

            string layout = string.Join(",", _items.Select((it, i) =>
                i + ":" + it.ColorName + "-" + it.Kind.ToString().ToLowerInvariant()));
            if (_logger != null)
                _logger.Log("trial", "trial", _trialIndex, "nonce", _nonce,
                            "target", "green circle", "target_slot", _targetSlot, "layout", layout,
                            "suite", SuiteNames.Name(_suite),
                            "case_id", _currentCase != null ? _currentCase.Id : "",
                            "case_index", _trialIndex,
                            "case_total", _suite == SuiteKind.Legacy ? 0 : _suiteCases.Length,
                            "expected_text", TextExpected()
                            , "platform", "windows", "native_text_policy_version", NativeTextPolicy.Version,
                            "native_control", NativeTextPolicy.Control,
                            "native_override_applied", NativeTextPolicy.Applies(_suite, _currentCase),
                            "task_payload", _currentCase.Payload,
                            "canonical_expected_text", _currentCase.ExpectedText,
                            "canonical_expected_utf16_hex", CaseContract.Utf16Hex(_currentCase.ExpectedText),
                            "native_expected_text", TextExpected(),
                            "native_expected_utf16_hex", CaseContract.Utf16Hex(TextExpected()),
                            "actual_normalized", false
                            );
        }

        private void NextTrial()
        {
            if (_suite != SuiteKind.Legacy && !_suiteFinished && _trialIndex >= _suiteCases.Length)
            {
                _suiteFinished = true;
                _statusLabel.Text = "SUITE COMPLETE — " + _suiteCases.Length + "/" + _suiteCases.Length + " cases";
                _statusLabel.ForeColor = Palette.Green;
                _statusLabel.BackColor = Color.FromArgb(209, 245, 209);
                if (_logger != null)
                    _logger.Log("suite_complete", "trial", _trialIndex, "suite", SuiteNames.Name(_suite),
                                "case_id", _currentCase != null ? _currentCase.Id : "",
                                "case_index", _trialIndex, "case_total", _suiteCases.Length);
                return;
            }
            StartTrial();
        }

        private void ShapeClicked(int slot)
        {
            bool hit = slot == _targetSlot;
            _statusLabel.Text = hit ? "TARGET HIT" : "WRONG TARGET";
            _statusLabel.ForeColor = hit ? Palette.Green : Palette.Red;
            _statusLabel.BackColor = hit ? Color.FromArgb(209, 245, 209) : Color.FromArgb(252, 214, 214);
            if (_logger != null)
                _logger.Log(hit ? "hit" : "wrong", "trial", _trialIndex, "nonce", _nonce,
                            "slot", slot, "target_slot", _targetSlot,
                            "suite", SuiteNames.Name(_suite),
                            "case_id", _currentCase != null ? _currentCase.Id : "",
                            "case_index", _trialIndex,
                            "case_total", _suite == SuiteKind.Legacy ? 0 : _suiteCases.Length);
        }

        private static int GraphemeCount(string s) { return new StringInfo(s).LengthInTextElements; }

        private string TextExpected()
        {
            return NativeTextPolicy.Expected(_suite, _currentCase);
        }

        private void CheckText()
        {
            string got = _textBox.Text; // Never rewrite/normalize the actual control value.
            string expected = TextExpected();
            _nativeTextCheckIndex++;
            // Exact UTF-16 code-unit comparison — no Trim, no Unicode normalization.
            bool matched = CaseContract.Utf16ExactMatch(got, expected);
            string expectedUtf16Hex = CaseContract.Utf16Hex(expected);
            string utf16Hex = CaseContract.Utf16Hex(got);
            int expectedLen = GraphemeCount(expected); // grapheme count, informational
            int gotLen = GraphemeCount(got);
            if (matched)
            {
                _resultLabel.Text = "MATCHED — " + gotLen + " characters";
                _resultLabel.ForeColor = Palette.Green;
            }
            else
            {
                _resultLabel.Text = "MISMATCH — expected " + expectedLen + ", got " + gotLen;
                _resultLabel.ForeColor = Palette.Red;
            }
            if (_logger != null)
                _logger.Log("text_check", "trial", _trialIndex, "nonce", _nonce,
                            "matched", matched, "expected_len", expectedLen, "got_len", gotLen,
                            "suite", SuiteNames.Name(_suite),
                            "case_id", _currentCase != null ? _currentCase.Id : "",
                            "case_index", _trialIndex,
                            "case_total", _suite == SuiteKind.Legacy ? 0 : _suiteCases.Length,
                            "task_payload", _currentCase != null ? _currentCase.Payload : "",
                            "expected_text", expected,
                            "actual_text", got,
                            "expected_utf16_hex", expectedUtf16Hex,
                            "actual_utf16_hex", utf16Hex
                            , "platform", "windows", "native_text_policy_version", NativeTextPolicy.Version,
                            "native_control", NativeTextPolicy.Control,
                            "native_override_applied", NativeTextPolicy.Applies(_suite, _currentCase),
                            "canonical_expected_text", _currentCase.ExpectedText,
                            "canonical_expected_utf16_hex", CaseContract.Utf16Hex(_currentCase.ExpectedText),
                            "native_expected_text", expected,
                            "native_expected_utf16_hex", expectedUtf16Hex,
                            "actual_normalized", false,
                            "check_index", _nativeTextCheckIndex,
                            "check_kind", _nativeTextCheckIndex == 1 ? "first" : "final"
                            );
        }
    }

    // MARK: - Entry point

    internal static class Program
    {
        private static int Fail(string msg)
        {
            Console.Error.WriteLine("error: " + msg);
            return 1;
        }

        [STAThread]
        static int Main(string[] args)
        {
            // Separate native policy manifest; legacy63/platform20/focus10 exports stay unchanged.
            // This branch precedes any WinForms initialization and refuses existing output files.
            if (args.Length > 0 && args[0] == "--export-native-text-policy")
            {
                try {
                    string path = NativeTextPolicy.ParseExport(args);
                    using (var writer = new StreamWriter(new FileStream(path, FileMode.CreateNew, FileAccess.Write), new UTF8Encoding(false)))
                        writer.Write(NativeTextPolicy.ManifestJson());
                    Console.WriteLine("exported Windows native text policy: " + path);
                    return 0;
                } catch (ArgumentException ex) { return Fail(ex.Message); }
                  catch (IOException ex) { return Fail(ex.Message); }
            }
            BasicArguments parsed;
            try { parsed = BasicArguments.Parse(args); }
            catch (ArgumentException ex) { return Fail(ex.Message); }
            ulong? seed = parsed.Seed;
            string evidencePath = parsed.EvidencePath, suiteName = parsed.Suite;
            bool selfTest = parsed.SelfTest;
            string exportPath = parsed.ExportPath;
            SuiteKind suite = SuiteKind.Legacy;
            SuiteNames.TryParse(suiteName, out suite);

            if (selfTest)
            {
                var results = SelfTest.Run();
                results.AddRange(GestureSelfTest.Run());
                results.AddRange(BasicSelfTest.Run());
                results.AddRange(FocusSelfTest.Run());
                results.AddRange(FocusRegression.Run());
                results.AddRange(NativeTextSelfTest.Run());
                results.AddRange(GeometrySelfTest.Run());
                results.AddRange(GeometryRegression.Run());
                int failed = 0;
                foreach (var r in results)
                {
                    Console.WriteLine((r.Passed ? "PASS" : "FAIL") + ": " + r.Name
                        + (r.Detail.Length > 0 ? " — " + r.Detail : ""));
                    if (!r.Passed) failed++;
                }
                Console.WriteLine(failed == 0
                    ? "SELF-TEST PASSED (" + results.Count + " checks)"
                    : "SELF-TEST FAILED (" + failed + "/" + results.Count + " checks failed)");
                return failed == 0 ? 0 : 1;
            }

            if (exportPath != null)
            {
                File.WriteAllText(exportPath, GestureExporter.ManifestJson(), new UTF8Encoding(false));
                Console.WriteLine("exported case manifest: " + exportPath);
                Console.WriteLine("WARNING: coordinator-only file (contains answers). Must NOT be placed in the GUI agent publish directory.");
                return 0;
            }

            if (parsed.PlatformExportPath != null)
            {
                File.WriteAllText(parsed.PlatformExportPath, BasicCatalog.ManifestJson(), new UTF8Encoding(false));
                Console.WriteLine("exported Windows-only B2 manifest (coordinator only): " + parsed.PlatformExportPath);
                return 0;
            }

            if (parsed.FocusExportPath != null)
            {
                File.WriteAllText(parsed.FocusExportPath, FocusCatalog.ManifestJson(), new UTF8Encoding(false));
                Console.WriteLine("exported Windows-only focus manifest (coordinator only): " + parsed.FocusExportPath);
                return 0;
            }

            if (parsed.GeometryExportPath != null)
            {
                try {
                    using (var writer = new StreamWriter(new FileStream(parsed.GeometryExportPath, FileMode.CreateNew, FileAccess.Write), new UTF8Encoding(false)))
                        writer.Write(GeometryCatalog.ManifestJson());
                    Console.WriteLine("exported Windows-only geometry manifest (coordinator only): " + parsed.GeometryExportPath);
                    return 0;
                } catch (IOException ex) { return Fail(ex.Message); }
            }

            if (suiteName == "geometry") GeometryNative.EnableOwnThreadDpi();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (suiteName == "geometry") {
                Application.Run(new GeometryForm(evidencePath));
            } else if (suiteName == "focus") {
                Application.Run(new FocusForm(evidencePath));
            } else if (BasicCatalog.IsBasic(suiteName)) {
                Application.Run(new BasicForm(suiteName, seed, evidencePath));
            } else if (GestureCatalog.IsGesture(suiteName)) {
                Application.Run(new GestureForm(suiteName, seed, evidencePath));
            } else {
                var form = new MainForm(suite, evidencePath, seed);
                form.Shown += (s, e) => ((MainForm)s).StartTrial();
                Application.Run(form);
            }
            return 0;
        }
    }
}
